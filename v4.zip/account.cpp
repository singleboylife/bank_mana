#include "account.h"
#include <iostream>
#include <iomanip>
#include <cmath>

using namespace std;

// ʵ��Account��ľ�̬��Ա�͹��캯��
double Account::total = 0;

Account::Account(const Date& date, const std::string& id) : id(id), balance(0) {
}

void Account::record(const Date& date, double amount, const std::string& desc) {
    amount = floor(amount * 100 + 0.5) / 100; // ����С�������λ
    balance += amount;
    total += amount;

    // ��ӡ���׼�¼
    cout << date;
    cout << "\t#" << id << "\t";
    if (amount >= 0)
        cout << setw(7) << left << amount;
    else
        cout << "-" << setw(6) << left << -amount;
    cout << "\t" << setw(7) << left << balance << "\t" << desc << endl;
}

void Account::error(const std::string& msg) const {
    cout << "Error(#" << id << "): " << msg << endl;
}

void Account::show() const {
    cout << id << "\tBalance: " << balance;
}

// ʵ��SavingsAccount��
SavingsAccount::SavingsAccount(const Date& date, const std::string& id, double rate)
    : Account(date, id), rate(rate), acc(date, 0) {
    cout << date << "\t#" << id << " created" << endl;
}

void SavingsAccount::deposit(const Date& date, double amount, const std::string& desc) {
    record(date, amount, desc);
    acc.change(date, getBalance());
}

void SavingsAccount::withdraw(const Date& date, double amount, const std::string& desc) {
    if (amount > getBalance()) {
        error("not enough money");
        return;
    }
    record(date, -amount, desc);
    acc.change(date, getBalance());
}

void SavingsAccount::settle(const Date& date) {
    // ֻ��ÿ��1��1�ս��н���
    if (date.getMonth() == 1 && date.getDay() == 1) {
        double interest = acc.getSum(date) * rate / 366; // ��������Ϣ
        if (interest != 0)
            record(date, interest, "interest");
        acc.reset(date, getBalance());
    }
}

// ʵ��CreditAccount��
CreditAccount::CreditAccount(const Date& date, const std::string& id,
    double credit, double rate, double fee)
    : Account(date, id), credit(credit), rate(rate), fee(fee), acc(date, 0) {
    cout << date << "\t#" << id << " created" << endl;
}

double CreditAccount::getDebt() const {
    double balance = getBalance();
    return (balance < 0 ? -balance : 0);
}

void CreditAccount::deposit(const Date& date, double amount, const std::string& desc) {
    record(date, amount, desc);
    if (getBalance() > 0) { // ��������������Ͳ���Ϣ��
        acc.reset(date, 0);
    }
    else { // ���򣬴�������Ƿ��
        acc.change(date, getDebt());
    }
}

void CreditAccount::withdraw(const Date& date, double amount, const std::string& desc) {
    if (amount - getBalance() > credit) { // ���ȡ��󳬹����ö��
        error("not enough credit");
        return;
    }
    record(date, -amount, desc);
    if (getBalance() < 0) { // ���ȡ�����Ƿ��
        acc.change(date, getDebt());
    }
}

void CreditAccount::settle(const Date& date) {
    double interest = 0;

    // ÿ��1�ս�����Ϣ
    if (date.getDay() == 1) {
        // ��������Ƿ���ܶ�
        interest = acc.getSum(date) * rate;
        if (interest != 0)
            record(date, -interest, "interest");
        acc.reset(date, getDebt());
    }

    // ÿ��1��1����ȡ���
    if (date.getMonth() == 1 && date.getDay() == 1) {
        record(date, -fee, "annual fee");
    }
}

void CreditAccount::show() const {
    Account::show();
    cout << "\tAvailable credit: " << getAvailableCredit();
}